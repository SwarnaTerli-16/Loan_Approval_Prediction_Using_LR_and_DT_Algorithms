from os import stat
from flask import Flask, render_template, request, url_for, redirect
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
import pickle
from sklearn.preprocessing import StandardScaler

app = Flask(__name__)
mymodel = pickle.load(open("model.pkl", "rb"))  # load model
myscaler = pickle.load(open("scaler.pkl", "rb"))
accuracy1 = pickle.load(open("accuracy1.pkl", "rb"))
accuracy2= pickle.load(open("accuracy2.pkl", "rb"))


@app.route('/')  # url binding
def loadhome():
    return render_template("homepage.html")


@app.route('/form', methods=['GET', 'POST'])
def form():
    return render_template("prediction.html")


@app.route('/prediction', methods=['GET', 'POST'])
def prediction():
    return redirect(url_for('form'))


@app.route('/accuracy')
def accuracy():
    #accuracy1 = pickle.load(open("accuracy1.pkl", "rb"))
    #accuracy2= pickle.load(open("accuracy2.pkl", "rb"))
    #accuracy3=pickle.load(open("accuracy3.pkl", "rb"))
    return render_template("accuracy.html", accuracy1=accuracy1, accuracy2=accuracy2)



@app.route('/submit', methods=['POST'])  # url binding
def user():
    gender = request.form['Gender']
    married = request.form['Married']
    Education = request.form["Education"]
    se = request.form['Self-Employed']
    ApplicantIncome = request.form["ApplicantIncome"]
    Coapplicant = request.form["Co-applicant"]
    LoanAmount = request.form["LoanAmount"]
    LoanAmountTerm = request.form["Loan-Amount-Term"]
    CreditHistory = request.form["Credit-History"]
    dependents = request.form["dependents"]
    property = request.form["property"]

    
    res = [float(ApplicantIncome), float(Coapplicant),
           float(LoanAmount), float(LoanAmountTerm)]
    a, b, c, d = myscaler.transform([res])[0]
    arrayofinputs = [[float(gender), float(married), float(dependents), float(
        Education), float(se), a, b, c, d, float(CreditHistory), float(property)]]

    y = mymodel.predict(arrayofinputs)
    
    if str(y[0]) == '1':
        status = 'approved'
    else:
        status = 'rejected'
    return render_template("result.html", output="The Loan status is "+status)
    


if __name__ == '__main__':
    app.run(debug=True, port=8000)
